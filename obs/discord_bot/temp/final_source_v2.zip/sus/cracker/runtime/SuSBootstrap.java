/*
 * Decompiled with CFR 0.152.
 */
package sus.cracker.runtime;

import java.lang.invoke.CallSite;
import java.lang.invoke.ConstantCallSite;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.reflect.Method;

public class SuSBootstrap {
    public static CallSite bootstrap(MethodHandles.Lookup lookup, String string, MethodType methodType) throws Throwable {
        MethodHandles.Lookup lookup2 = MethodHandles.lookup();
        MethodType methodType2 = methodType;
        String string2 = string;
        return new ConstantCallSite(MethodHandles.lookup().unreflect((Method)((Object)methodType)));
    }
}

