/*
 * Decompiled with CFR 0.152.
 */
package sus.cracker.runtime;

import java.nio.charset.StandardCharsets;
import java.util.Base64;

public class SuSProtector {
    public static String decrypt(String string) {
        byte[] byArray = Base64.getDecoder().decode(string);
        for (int i = 0; i < byArray.length; ++i) {
            byArray[i] = (byte)(byArray[i] ^ 0x5A);
        }
        return new String(byArray, StandardCharsets.UTF_8);
    }
}

